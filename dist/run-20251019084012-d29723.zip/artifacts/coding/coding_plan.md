# Coding Plan (nextjs-dashboard)

## Primary Tasks
- Initialise repository structure and configuration.
- Generate baseline code scaffolding aligning with requirements.
- Create smoke tests to validate critical paths.

## Suggested Commands
- `git init`
- `npm create next-app@latest . --use-npm --ts --app --eslint`
- `npm install @tanstack/react-table`

## Key Files / Directories
- README.md
- tests/
- app/page.tsx
- app/layout.tsx

## Model Notes
Below is a concise, prioritized implementation plan for a Next.js dashboard project. It lists the key coding tasks, recommended shell commands, and the primary files/folders to create (with short descriptions) so you can quickly scaffold and implement the product.

High-level assumptions
- Next.js (prefer app router or pages router — pick one); TypeScript
- Tailwind or Chakra/MUI for UI
- React Query or SWR for remote data
- JWT/session auth (NextAuth or custom)
- Optional backend persistence (Prisma + PostgreSQL) or API stubs for serverless endpoints

1) Generate repo & scaffold
- Tasks:
  - Create Next.js app with TypeScript and app router (or pages if preferred)
  - Initialize git
- Commands:
  - npx create-next-app@latest my-dashboard --typescript --app
  - cd my-dashboard
  - git init && git add . && git commit -m "chore: scaffold project"
- Primary files created by scaffold: package.json, tsconfig.json, next.config.js, app/ (or pages/), public/

2) Tooling & linting
- Tasks:
  - Add ESLint, Prettier, Husky, lint-staged
  - Configure TypeScript strict rules
- Commands:
  - npm install -D eslint prettier eslint-config-prettier eslint-plugin-react eslint-plugin-react-hooks
  - npm install -D husky lint-staged
  - npx husky install
  - (Add lint-staged to package.json)
- Primary files to add:
  - .eslintrc.js — ESLint config
  - .prettierrc — Prettier config
  - .husky/pre-commit — run lint-staged
  - .vscode/ (optional) workspace settings

3) UI framework & design tokens
- Tasks:
  - Add TailwindCSS or Chakra/MUI, set up global theme
  - Define color tokens, spacing, font
- Commands (Tailwind):
  - npm install -D tailwindcss postcss autoprefixer
  - npx tailwindcss init -p
  - (update tailwind.config.js and globals.css)
- Primary files:
  - styles/globals.css — Tailwind entry
  - app/layout.tsx (or pages/_app.tsx) — theme provider and global styles
  - design/tokens.ts (or theme.ts) — central theme file

4) Auth and user session
- Tasks:
  - Implement auth (NextAuth.js or custom JWT)
  - Protect dashboard routes and redirect to login
- Commands:
  - npm i next-auth (or add jwt libs)
- Primary files:
  - app/api/auth/[...nextauth]/route.ts (NextAuth) or pages/api/auth/*.ts
  - lib/auth.ts — auth helpers
  - contexts/AuthContext.tsx — session provider (if custom)
  - app/login/page.tsx — login form

5) Data fetching & caching
- Tasks:
  - Add React Query or SWR and create client
  - Create hooks for dashboard data (metrics, tables, charts)
- Commands:
  - npm i @tanstack/react-query axios
- Primary files:
  - lib/api.ts — axios instance and wrapper
  - lib/queryClient.ts — React Query client setup
  - hooks/useDashboardMetrics.ts, hooks/useTableData.ts

6) Dashboard pages & routing
- Tasks:
  - Build main dashboard page and supporting pages (users, settings, reports)
  - Implement layout: header, sidebar, content area
- Primary files:
  - app/dashboard/layout.tsx (or pages/dashboard/_app.tsx)
  - app/dashboard/page.tsx — main dashboard
  - components/Header.tsx, components/Sidebar.tsx, components/Breadcrumbs.tsx
  - components/widgets/StatCard.tsx, components/widgets/ActivityChart.tsx

7) Data visualization & tables
- Tasks:
  - Integrate charting library and a robust table with sorting/pagination
- Commands:
  - npm i recharts react-table (or chart.js/echarts, tanstack table)
- Primary files:
  - components/charts/LineChart.tsx, components/charts/BarChart.tsx
  - components/Table.tsx — reusable table component

8) Forms, CRUD, and validation
- Tasks:
  - Add form library and validation (react-hook-form + zod or yup)
  - Implement create/update/delete flows with optimistic updates
- Commands:
  - npm i react-hook-form zod @hookform/resolvers
- Primary files:
  - components/forms/UserForm.tsx
  - pages/api/users/*.ts or app/api/users/route.ts — API handlers
  - services/userService.ts — server/client API wrappers

9) Server/API & persistence (optional)
- Tasks:
  - Add API routes (Next.js API or integrated server)
  - Add database layer (Prisma + PostgreSQL)
- Commands:
  - npm i prisma @prisma/client
  - npx prisma init
  - npx prisma migrate dev --name init
- Primary files:
  - prisma/schema.prisma
  - pages/api/* or app/api/* routes (e.g., app/api/metrics/route.ts)
  - lib/db.ts — database client singleton

10) Tests & component docs
- Tasks:
  - Add unit and integration tests, optionally Storybook
- Commands:
  - npm i -D vitest @testing-library/react @testing-library/jest-dom
  - npx sb init (optional)
- Primary files:
  - vitest.config.ts, test/setup.ts
  - __tests__/dashboard.test.tsx
  - .storybook/ (optional) and stories/*.stories.tsx

11) CI / CD & deployment
- Tasks:
  - Add GitHub Actions for lint/test/build + optional Docker
  - Configure Vercel or other hosting
- Commands:
  - (no commands; create workflow file)
- Primary files:
  - .github/workflows/ci.yml
  - Dockerfile (optional)
  - vercel.json (optional)
  - .env.example — required env variables documented

12) Observability & telemetry
- Tasks:
  - Add Sentry/logging/analytics
- Commands:
  - npm i @sentry/nextjs (optional)
- Primary files:
  - sentry.server.config.js, sentry.client.config.js (if using Sentry)

13) QA, accessibility, and polish
- Tasks:
  - Run axe/accessibility tests, keyboard navigation, mobile responsiveness
  - Finalize layout polish, micro-interactions, and loading states

Structured artifacts to produce (deliverables)
- Feature list & acceptance criteria (Markdown)
- UI component inventory (list of components + states)
- API contract document (endpoints, request/response shapes)
- Data model (ERD or Prisma schema)
- Route map (pages and access guards)
- Test plan (critical user flows)
- Deploy checklist (.env keys, secrets, build commands)

Concise primary file/folder map (create these)
- package.json — deps & scripts
- next.config.js — Next config
- tsconfig.json — TypeScript
- .eslintrc.js, .prettierrc
- app/ or pages/
  - app/layout.tsx (global layout)
  - app/page.tsx (home)
  - app/dashboard/page.tsx
  - app/login/page.tsx
  - app/settings/page.tsx
- app/api/
  - app/api/auth/route.ts
  - app/api/metrics/route.ts
  - app/api/users/route.ts
- components/
  - Header.tsx, Sidebar.tsx, Footer.tsx
  - widgets/StatCard.tsx, widgets/ActivityChart.tsx
  - charts/LineChart.tsx, Table.tsx
  - forms/UserForm.tsx
- lib/
  - api.ts (axios)
  - queryClient.ts
  - auth.ts
  - db.ts (if using Prisma)
- hooks/
  - useDashboardMetrics.ts, useUsers.ts
- prisma/
  - schema.prisma (optional)
- scripts/
  - seed.ts (optional)
- .github/workflows/ci.yml
- Dockerfile (optional)
- .env.example
- README.md (project setup + run + deploy instructions)

Recommended NPM scripts (add to package.json)
- "dev": "next dev"
- "build": "next build"
- "start": "next start"
- "lint": "next lint"
- "format": "prettier --write ."
- "test": "vitest"
- "typecheck": "tsc --noEmit"

Quick prioritized short-term checklist (first 2–5 days)
1. Scaffold app + TypeScript + linting + tailwind
2. Build global layout, header, sidebar
3. Implement auth + protected dashboard route
4. Add data-fetching client + example metrics endpoint
5. Implement core dashboard widgets (stats, chart, table)
6. Add tests for auth and main dashboard page
7. Setup CI (lint/test) and deploy to Vercel

If you want, I can generate:
- a ready-to-run package.json + scripts,
- a scaffolded folder tree with blank files,
- or the contents of a specific primary file (e.g., app/layout.tsx or components/Sidebar.tsx). Which would you like next?

# Testing Plan

Command: `npm run test -- --watch=false`

## Smoke Tests
- renders dashboard page placeholder
- README scaffold present

Tests not executed (dry-run/skipped).

# Coding Plan (nextjs-dashboard)

## Primary Tasks
- Initialise repository structure and configuration.
- Generate baseline code scaffolding aligning with requirements.
- Create smoke tests to validate critical paths.

## Suggested Commands
- `git init`
- `npm create next-app@latest . --use-npm --ts --app --eslint`
- `npm install @tanstack/react-table`

## Key Files / Directories
- README.md
- tests/
- app/page.tsx
- app/layout.tsx

## Model Notes
Assumptions
- Next.js (v13+) with the app router and TypeScript.
- A modern stack: Tailwind CSS for styling, Prisma + PostgreSQL for persistence, NextAuth (or alternative) for auth, TanStack Query for client data fetching.
- You want a production-ready dashboard scaffold (auth, layout, data layer, charts, CI, tests, deployment).

Implementation plan — milestones, key tasks, commands, and primary files

1) Project init & basic tooling
- Tasks
  - Create Next.js TypeScript app with app router.
  - Initialize repo, setup lint/format.
- Recommended commands
  - npx create-next-app@latest my-dashboard --typescript --app
  - cd my-dashboard
  - git init && gh repo create (or create manually) && git add . && git commit -m "init"
  - npm install -D eslint prettier eslint-config-prettier eslint-plugin-react
  - npm run dev
- Primary files
  - package.json (scripts)
  - tsconfig.json
  - next.config.js
  - .eslintrc.cjs, .prettierrc

2) Styling & design tokens
- Tasks
  - Install and configure Tailwind CSS; add global styles and design tokens.
- Commands
  - npm install -D tailwindcss postcss autoprefixer
  - npx tailwindcss init -p
- Primary files
  - tailwind.config.js
  - postcss.config.js
  - styles/globals.css (import Tailwind + custom tokens)
  - src/styles/tokens.css or design-tokens.json

3) Authentication & authorization
- Tasks
  - Implement NextAuth (or Clerk) with email/password or OAuth and RBAC/roles.
  - Add auth layouts and protected-route wrapper.
- Commands
  - npm install next-auth @next-auth/prisma-adapter
- Primary files
  - app/(auth)/login/page.tsx
  - app/(auth)/register/page.tsx
  - app/layout.tsx (root layout with session provider)
  - app/(dashboard)/dashboard/layout.tsx (protected)
  - app/api/auth/[...nextauth]/route.ts
  - lib/prisma.ts, lib/auth.ts

4) Data layer & database
- Tasks
  - Add Prisma, define schema for users, organizations, metrics, widgets.
  - Configure migrations and seed data.
- Commands
  - npm install prisma @prisma/client
  - npx prisma init
  - npx prisma migrate dev --name init
  - npx prisma db seed
- Primary files
  - prisma/schema.prisma
  - prisma/seed.ts
  - lib/prisma.ts (Prisma client singleton)
  - .env.example (DATABASE_URL)

5) API & business logic
- Tasks
  - Create REST or RPC endpoints (server actions or /api routes) for dashboard data, widgets, settings, users.
  - Add validation (zod or yup).
- Commands
  - npm install zod
- Primary files
  - app/api/dashboard/route.ts (GET/POST)
  - app/api/widgets/route.ts
  - server/actions.ts or lib/services/*.ts
  - schemas/*.ts (zod schemas)

6) Client data fetching & state
- Tasks
  - Integrate TanStack Query for fetching/caching; use React Context or Zustand for local UI state.
- Commands
  - npm install @tanstack/react-query axios
- Primary files
  - lib/api-client.ts (axios instance)
  - hooks/useQueryClient.ts, hooks/useDashboard.ts
  - store/uiStore.ts (Zustand if used)

7) UI components & pages
- Tasks
  - Build reusable components: Sidebar, Topbar, Card, Table, Modal, Form components, Chart component.
  - Implement main dashboard page with charts and widgets.
- Commands
  - npm install react-chartjs-2 chart.js (or recharts)
  - npm install react-hook-form
- Primary files
  - components/Layout.tsx, Sidebar.tsx, Topbar.tsx
  - components/Card.tsx, Table.tsx, Modal.tsx, Form/* (FormField.tsx, Input.tsx)
  - components/Chart.tsx
  - app/dashboard/page.tsx (main dashboard)
  - app/settings/page.tsx, app/users/page.tsx

8) Forms, validation & UX flows
- Tasks
  - Use react-hook-form + zod for forms; show validations and server-side error flows.
- Commands
  - npm install react-hook-form @hookform/resolvers
- Primary files
  - components/forms/* and app routes for create/edit actions

9) Testing & quality
- Tasks
  - Add unit tests, integration tests and E2E (Playwright).
  - Add CI workflow to run tests, lint, and build.
- Commands
  - npm install -D vitest @testing-library/react @testing-library/jest-dom
  - npm init playwright@latest (or npx playwright install)
- Primary files
  - vitest.config.ts
  - tests/unit/*.test.tsx
  - playwright.config.ts, e2e/*.spec.ts
  - .github/workflows/ci.yml

10) Migrations, seeding & observability
- Tasks
  - Setup Prisma migrations in CI, add simple logging and basic metrics/analytics.
- Commands
  - npx prisma migrate deploy (for production)
  - npx prisma db seed
- Primary files
  - prisma/migrations/*
  - scripts/seed.ts
  - lib/logger.ts

11) Deployment & environment
- Tasks
  - Configure Vercel (or other), environment variables, secrets, production DB.
  - Add monitor/alerts.
- Commands
  - git push origin main
  - Deploy via Vercel CLI or CI
- Primary files
  - .env.example
  - vercel.json (optional)
  - README.md with deploy steps

12) Documentation & deliverables
- Tasks
  - Generate API spec, ERD (artifact), and a short developer setup doc.
- Commands/tools
  - Use OpenAPI generator or document endpoints in README; export Prisma ERD using dbdiagram or draw.io.
- Primary files (artifacts)
  - docs/API.md (contracts)
  - docs/ERD.png or diags/
  - docs/architecture.md
  - README.md (dev setup + env vars)

Minimal package.json scripts to add
- "dev": "next dev"
- "build": "next build"
- "start": "next start"
- "lint": "next lint"
- "format": "prettier --write ."
- "migrate": "prisma migrate dev"
- "db:seed": "ts-node prisma/seed.ts"
- "test": "vitest"
- "e2e": "playwright test"

Suggested folder structure (concise)
- app/
  - layout.tsx, page.tsx, dashboard/page.tsx, settings/page.tsx
  - api/...
- components/
  - Layout.tsx, Sidebar.tsx, Topbar.tsx, Card.tsx, Chart.tsx, forms/
- lib/
  - prisma.ts, api-client.ts, auth.ts, logger.ts
- hooks/
  - useUser.ts, useDashboard.ts
- prisma/
  - schema.prisma, seed.ts, migrations/
- styles/
  - globals.css
- tests/, e2e/
- docs/, .github/workflows/

Priorities for first 1–2 sprints
1. Project scaffold, Tailwind, routing, layout, global styles.
2. Auth (NextAuth) + Prisma user model + DB migration.
3. Dashboard route + sample data fetch + core UI components (Sidebar, Topbar, Card, Chart).
4. Add TanStack Query + API endpoints + seed sample data.
5. Tests baseline + CI + deployment to Vercel.

If you want, I can:
- produce concrete package.json and initial scripts,
- generate a starter file tree with boilerplate code for app/layout.tsx, lib/prisma.ts, and a sample dashboard page,
- or adapt this plan to a different stack choice (pages router, Supabase, tRPC, or non-TypeScript).

def test_dashboard_metadata():
    assert "dashboard" in "dashboard placeholder".lower()

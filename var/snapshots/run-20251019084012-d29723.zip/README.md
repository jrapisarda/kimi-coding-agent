# Next.js Reference Workspace

Placeholder directory used during integration testing of the Kimi agent pipeline.

- Keep this folder under source control so snapshot/packaging flows have a real workspace.
- Future sprints can populate it with generated Next.js artifacts.
